"use strict"

/*function teste(){
    let nome="Sabrina"
    if(true){
        console.log("dentro do if teste: " + nome)
    }
    console.log("dentro da função teste: " + nome)
}*/

let nome = "Sabrina"
nome = "Mendonça"
nome=19

const curso = "JavaScript" //nao é possivel alterar o valor de uma cons

//teste()

//console.log("fora do teste" + nome);

//dentro da função o var continua dando erro 