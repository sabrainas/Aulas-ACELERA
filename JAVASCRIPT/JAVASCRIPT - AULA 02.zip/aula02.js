"use scrict"

let nome = "Sabrina"
console.log(nome);

console.log("CFB Cursos");
console.log("Nome: " + nome);