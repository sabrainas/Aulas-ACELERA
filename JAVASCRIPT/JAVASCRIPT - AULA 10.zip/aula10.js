let num=10
let num2=5
res=(!(num%2) ? "Par" : "Impar")

res2=(num > num2 ? "Verdadeiro" : "Falso")

console.log(res)
console.log(res2)

//0 = false
//1 = true

//teste lógico ? se verdadeiro : se falso

// if(res==0){
//     console.log("Par")
// }else{
//     console.log("Impar")
// }