let n=-10

n+=9

console.log(n++)
console.log(n)

let num1=10
let num2=20

console.log(num1 + "" + num2)// concatenação