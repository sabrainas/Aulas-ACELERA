// let n=0

// while(n<10){
//     console.log(n++)
// }

//5! = 5*4*3*2*1

let num=12
let fat=1

while(num>=1){
    fat*=num
    num--
}

console.log(fat)