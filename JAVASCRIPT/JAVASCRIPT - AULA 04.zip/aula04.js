let num1=1,num2=2,num3=3

num1=10
num1++

res=(num1+num2)*2

console.log(num1)
console.log(num2)
console.log(num3)
console.log(res)