let v1=10
let v2='10'
let v3=v1===v2
let v4={nome:"Sabrina"}

console.log("valor: " + v1 + " - Tipo: " + typeof(v1))
console.log("valor: " + v2 + " - Tipo: " + typeof(v2))
console.log("valor: " + v3 + " - Tipo: " + typeof(v3))
console.log("valor: " + v4 + " - Tipo: " + typeof(v4))
